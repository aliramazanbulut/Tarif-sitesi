const tarif = document.querySelector(".tarif");
const searchForm = document.querySelector(".search-form");
const searchBtn= document.querySelector("#search-btn");
const searchBtn2= document.querySelector("#search-btn2");
const navbar =document.querySelector(".navbar");
const menuBtn= document.querySelector("#menu-btn");
const ekle= document.querySelector("#tarif");
const homeBtn = document.querySelector("#home");
const iletisimBtn = document.querySelector("#iletisim");
const kategori = document.querySelector("#kategori");
const searchContainer = document.querySelector("#search-container");
const login = document.querySelector("#log-in");
const btn1= document.querySelector("#btn1");
const mainContainer = document.querySelector("#main-container");
const categoryContainer = document.querySelector("#category-container");
const girisbtn = document.querySelector("#btnlog-in");
const savedvalue = Number(localStorage.getItem("durum"));
const signUp = document.querySelector("#sign-up");
const logOut = document.querySelector("#log-out");
const viewContainer= document.querySelector("#view-container");

let viewmetin=[];
let tutucu =JSON.parse(localStorage.getItem('tutucu'));
console.log("tutucu",localStorage.getItem('tutucu')); 

let aramametin=JSON.parse(localStorage.getItem('aramametin'));
console.log("Saved Value: ", savedvalue);
console.log(aramametin);

let kullanici= JSON.parse(localStorage.getItem('kullanici'))
console.log(kullanici);

let tarifmetin = JSON.parse(localStorage.getItem('tarifmetin'));
console.log("metin" ,tarifmetin);

let tarifler = JSON.parse(localStorage.getItem('tarifler'));
console.log("mtarif" ,tarifler);
let kategoriler=[ 
    {"id": 1, "ad":"TATLILAR"},
    {"id": 2, "ad":"YEMEKLER"},
    {"id": 3, "ad":"ÇORBALAR"},
];
let kayıtlar=[

];
let users = JSON.parse(localStorage.getItem('users'));
console.log(users);
for (let list of tarifmetin){
    if(tutucu == list.id){viewmetin.push(list);}
}
console.log("a",viewmetin);


searchBtn.addEventListener("click", function(){
    searchForm.classList.toggle("active");
    document.addEventListener("click", function(e) {
if(!e.composedPath().includes(searchBtn) && !e.composedPath().includes(searchForm))
{  searchForm.classList.remove("active");}
    });
} );
menuBtn.addEventListener("click", function(){
    navbar.classList.toggle("active");
    document.addEventListener("click", function(e) {
if(!e.composedPath().includes(menuBtn) && !e.composedPath().includes(navbar))
{  navbar.classList.remove("active");}
    });
} );

logOut.addEventListener("click", function(){
    localStorage.setItem("durum", 0);
    kullanici = null;
    localStorage.setItem('kullanici', JSON.stringify(kullanici));
    window.location.href = "index.html";
})
