const express = require('express');
const sql = require('mssql');
const cors = require('cors');
const app = express();
const corsOptions = {
    origin: '*', // Burada '*' tüm kaynaklardan gelen isteklere izin verir
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'], // Hangi HTTP metodlarına izin verileceğini belirtiyoruz
    allowedHeaders: ['Content-Type', 'Authorization'], // Hangi başlıkların kabul edileceğini belirtiyoruz
    preflightContinue: false, // Preflight isteği yapıldığında yanıt vermek
    optionsSuccessStatus: 204, // Başarı durum kodu (bu, bazı eski tarayıcılar için gereklidir)
};
app.options('*', cors(corsOptions));

app.use(cors(corsOptions));

app.use(express.json());

const config = {
    server: 'localhost', 
    database: 'tarifler', 
    options: {
        encrypt: false, 
        enableArithAbort: true,
    },
    authentication: {
        type: 'ntlm', 
        options: {
            domain: '', 
            userName: '', 
            password: '', 
        },
    },
};
try {
    const pool = await sql.connect(config);
    console.log('Veritabanına başarıyla bağlanıldı');
} catch (err) {
    console.error('Veritabanı bağlantı hatası:', err);
}
app.post('/save-recipe', async (req, res) => {
    const { tarifName, tarifHzrlk, tarifMalzeme, tarifKategori } = req.body;

    if (!tarifName || !tarifHzrlk || !tarifMalzeme || !tarifKategori) {
        return res.status(400).send('Eksik veri gönderildi');
    }

    try {
        const pool = await sql.connect(config);
        await pool.request()
            .input('tarifName', sql.NVarChar, tarifName)
            .input('tarifHzrlk', sql.NVarChar, tarifHzrlk)
            .input('tarifMalzeme', sql.NVarChar, tarifMalzeme)
            .input('tarifKategori', sql.NVarChar, tarifKategori)
            .query(`
                INSERT INTO tarifler (ad, hazırlık, malzemeler, kategori) 
                VALUES (@tarifName, @tarifHzrlk, @tarifMalzeme, @tarifKategori)
            `);

        res.status(200).send('Tarif başarıyla kaydedildi');
    } catch (err) {
        console.error('Veri eklerken hata oluştu:', err);
        res.status(500).send('Veritabanı hatası');
        
    } finally {
        await pool.close();
    }
});

app.options('*', cors(corsOptions));

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Sunucu http://localhost:${PORT} adresinde çalışıyor`);
});